import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(title: 'REST Demo', home: TareasRest());
  }
}

class TareasRest extends StatefulWidget {
  @override
  _TareasRestState createState() => _TareasRestState();
}

class _TareasRestState extends State<TareasRest> {
  List Tareas = [];
  Future <void>obtenerTareas() async {
    try{
      final url=Uri.parse('https://jsonplaceholder.typicode.com/todos');
      final respuesta=await http.get(url);
      if(respuesta.statusCode==200){
      final datos=json.decode(respuesta.body);
      setState(() {
        Tareas = datos.take(10).toList();
      });
    }else{
      print('Error en la respuesta: ${respuesta.statusCode}');
    }
  } catch (e) {
    print('ocurrio un error:$e');
  }
}
  @override
  void initState() {
    super.initState();
    obtenerTareas();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Tareas desde REST')),
      body: ListView.builder(
        itemCount: Tareas.length,
        itemBuilder: (context, index) {
          final Tarea = Tareas[index];
          return ListTile(
            title: Text(Tarea['title']),
            trailing: Icon(
              Tarea['completed'] ? Icons.check : Icons.close,
              color: Tarea['completed'] ? Colors.green : Colors.red,
            ),
          );
        },
      ),
    );
  }
}
